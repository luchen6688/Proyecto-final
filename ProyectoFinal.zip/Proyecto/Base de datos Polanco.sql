﻿create database BibliotecaPolanco
use BibliotecaPolanco

Create table Libro (
    ISBN char(13) primary key,
    Titulo nvarchar(255) not null,
    Autor nvarchar(255) not null,
    Editorial nvarchar(255),
    AñoPublicacion int,
    Genero nvarchar(100),
    NumeroCopia int default 1
);

Create table Usuario (
    IdUsuario int primary key identity(1,1),
    Nombre nvarchar(100) not null,
    Apellido nvarchar(100) not null,
    Email nvarchar(255) unique not null,
    Telefono nvarchar(15)
);


Create table Reserva (
    IdReserva int primary key identity(1,1), 
    IdUsuario int not null,
    ISBN char(13) not null,
    FechaReserva date not null,
    FechaRetorno date not null,

    CONSTRAINT FK_Reserva_Usuario FOREIGN KEY (IdUsuario)
        REFERENCES Usuario(IdUsuario) ON DELETE CASCADE, 
    CONSTRAINT FK_Reserva_Libro FOREIGN KEY (ISBN)
        REFERENCES Libro(ISBN) ON DELETE CASCADE
);

insert into Libro (ISBN, Titulo, Autor, Editorial, AñoPublicacion, Genero, NumeroCopia)
values 
('9780807283158', 'Harry Potter y el Prisonero de Azkaban', 'J K Rowling', 'Bloomsbury Salamandra Scholastic', 2004, 'Realismo Mágico', 3),
('9789876543210', 'Don Quijote de la Mancha', 'Miguel de Cervantes', 'Francisco de Robles', 1605, 'Novela', 5),
('9780307245304', 'Percy jackson y el ladron del rayo', 'GRick Riordan', '	‎Disney Hyperion', 2006, 'Realismo magico', 4);

insert into Usuario (Nombre, Apellido, Email, Telefono)
values 
('Erick', 'Pérez', 'Eric.Perez@gmail.com', '555-3412'),
('Gissel', 'Ventura', 'Giselle.ventura@gmail.com', '555-5678'),
('Juan', 'David', 'Juan.David@gmail.com', '555-8765');

insert into Reserva (IdUsuario, ISBN, FechaReserva, FechaRetorno)
values 
(1, '9781234567890', '2024-10-10', '2024-11-10'),
(2, '9789876543210', '2024-10-11', '2024-11-12'),
(3, '9788523456789', '2024-10-12', '2024-11-13');