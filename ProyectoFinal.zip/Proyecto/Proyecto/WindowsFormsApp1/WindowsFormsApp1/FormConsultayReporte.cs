﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoBiblio
{
    public partial class FormConsultayReporte : Form
    {

        private Conexion conexionDB = new Conexion ();
        public FormConsultayReporte()
        {
            InitializeComponent();
            Libros();
            Mostrar();
            LibrosReservados();
            ClientessReservados();


        }

        private void Libros()
        {
            string query = "SELECT DISTINCT Genero FROM Libro";

            using (SqlConnection conn = conexionDB.Conectar())
            {
                try
                {
                    using (SqlDataAdapter da = new SqlDataAdapter(query, conn))
                    {
                        DataTable dt = new DataTable();
                        da.Fill(dt);

                      
                        if (dt.Rows.Count > 0)
                        {
                            comboBox1.DataSource = dt;
                            comboBox1.DisplayMember = "Genero";
                            comboBox1.ValueMember = "Genero";
                        }
                        else
                        {
                            MessageBox.Show("No se encontraron géneros de libros en la base de datos.");
                        }
                    }
                }
                catch (SqlException sqlEx)
                {
                  
                    MessageBox.Show("Error SQL al cargar géneros de libros: " + sqlEx.Message);
                }
                catch (Exception ex)
                {
                
                    MessageBox.Show("Error al cargar géneros de libros: " + ex.Message);
                }
            }

        }


        private void Mostrar()
        {
            string query = "SELECT * FROM Libro WHERE Genero = @Genero AND NumeroCopia > 0";

            using (SqlConnection conn = conexionDB.Conectar())
            {
                try
                {
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                    
                        cmd.Parameters.AddWithValue("@Genero", comboBox1.SelectedValue ?? (object)DBNull.Value);

                        using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                        {
                            DataTable dt = new DataTable();
                            da.Fill(dt);

                          
                            if (dt.Rows.Count > 0)
                            {
                                dataGridView1.DataSource = dt;
                            }
                            else
                            {
                                MessageBox.Show("No se encontraron libros disponibles para este género.");
                                dataGridView1.DataSource = null; 
                            }
                        }
                    }
                }
                catch (SqlException sqlEx)
                {
                   
                    MessageBox.Show("Error SQL al cargar libros: " + sqlEx.Message);
                }
                catch (Exception ex)
                {
                  
                    MessageBox.Show("Error al cargar libros: " + ex.Message);
                }
            }

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void FormConsultayReporte_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Mostrar();
        }

        private void LibrosReservados()
        {
            string query = "Select L.ISBN, L.Titulo, L.Autor, L.Genero, COUNT(R.ISBN) AS TotalReserva from Libro L JOIN Reserva R ON L.ISBN = R.ISBN GROUP BY L.ISBN, L.Titulo, L.Autor, L.Genero ORDER BY TotalReserva DESC";

            using (SqlConnection conn = conexionDB.Conectar())
            {
                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                dataGridView2.DataSource = dt;
            }
        }

        private void ClientessReservados()
        {
            string query = "Select C.IdUsuario, C.Nombre, C.Apellido, C.Email from Usuario C JOIN Reserva R on C.IdUsuario = R.IdUsuario GROUP BY C.IdUsuario, C.Nombre, C.Apellido, C.Email ORDER BY COUNT(R.IdUsuario) DESC";

            using (SqlConnection conn = conexionDB.Conectar())
            {
                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                dataGridView3.DataSource = dt;
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
