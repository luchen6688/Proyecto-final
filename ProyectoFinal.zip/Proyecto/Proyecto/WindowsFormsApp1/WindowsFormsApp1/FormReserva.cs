﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace ProyectoBiblio
{
    public partial class FormReserva : Form
    {
        private Conexion Conexiones = new Conexion();
        public FormReserva()
        {
            InitializeComponent();
            Libro();
            Usuario();
            Reserva();
        }

        private void Reserva()
        {
            string query = "Select R.IdReserva, R.IdUsuario, (C.Nombre + '' + C.Apellido)as Usuario, R.ISBN, L.Titulo, R.FechaReserva, R.FechaRetorno from Reserva R join Usuario C on R.IdUsuario = C.IdUsuario join Libro L on R.ISBN = L.ISBN";

            using (SqlConnection conn = Conexiones.Conectar())
            {
                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);


                dataGridView1.DataSource = dt;
            }
        }
        private void Libro()
        {
            string query = "SELECT ISBN, Titulo FROM Libro";

            using (SqlConnection conn = Conexiones.Conectar())
            {
                try
                {
                    using (SqlDataAdapter da = new SqlDataAdapter(query, conn))
                    {
                        DataTable dt = new DataTable();
                        da.Fill(dt);

                   
                        if (dt.Rows.Count > 0)
                        {
                            comboBox2.DataSource = dt;
                            comboBox2.DisplayMember = "Titulo";
                            comboBox2.ValueMember = "ISBN";
                        }
                        else
                        {
                            MessageBox.Show("No se encontraron libros en la base de datos.");
                        }
                    }
                }
                catch (SqlException sqlEx)
                {
                  
                    MessageBox.Show("Error SQL al cargar libros: " + sqlEx.Message);
                }
                catch (Exception ex)
                {
                  
                    MessageBox.Show("Error al cargar libros: " + ex.Message);
                }
            }


        }

        private void Usuario()
        {
            string query = "SELECT IdUsuario, (Nombre + ' ' + Apellido) AS Usuario FROM Usuario";

            using (SqlConnection conn = Conexiones.Conectar())
            {
                try
                {
                    using (SqlDataAdapter da = new SqlDataAdapter(query, conn))
                    {
                        DataTable dt = new DataTable();
                        da.Fill(dt);

                     
                        if (dt.Rows.Count > 0)
                        {
                            comboBox1.DataSource = dt;
                            comboBox1.DisplayMember = "Usuario";
                            comboBox1.ValueMember = "IdUsuario";
                        }
                        else
                        {
                            MessageBox.Show("No se encontraron usuarios en la base de datos.");
                        }
                    }
                }
                catch (SqlException sqlEx)
                {
                    MessageBox.Show("Error SQL al cargar usuarios: " + sqlEx.Message);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al cargar usuarios: " + ex.Message);
                }
            }

        }


        private void FormReserva_Load(object sender, EventArgs e)
        {

        }
        private void Boton_agregar_Click(object sender, EventArgs e)
        {
            string query = "INSERT INTO Reservas (IdUsuario, ISBN, FechaReserva, FechaRetorno) " +
               "VALUES (@IdUsuario, @ISBN, @FechaReserva, @FechaRetorno)";

            using (SqlConnection conn = Conexiones.Conectar())
            {
                try
                {
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        
                        cmd.Parameters.Add("@IdUsuario", SqlDbType.Int).Value = comboBox1.SelectedValue ?? (object)DBNull.Value;
                        cmd.Parameters.Add("@ISBN", SqlDbType.VarChar).Value = comboBox2.SelectedValue ?? (object)DBNull.Value;
                        cmd.Parameters.Add("@FechaReserva", SqlDbType.DateTime).Value = dateTimePicker1.Value;
                        cmd.Parameters.Add("@FechaRetorno", SqlDbType.DateTime).Value = dateTimePicker2.Value;

                       
                        int filasAfectadas = cmd.ExecuteNonQuery();

                        if (filasAfectadas > 0)
                        {
                            MessageBox.Show("Reserva agregada correctamente");
                            Reserva(); 
                        }
                        else
                        {
                            MessageBox.Show("No se pudo agregar la reserva. Inténtelo de nuevo.");
                        }
                    }
                }
                catch (SqlException sqlEx)
                {
                  
                    MessageBox.Show("Error SQL al agregar la reserva: " + sqlEx.Message);
                }
                catch (Exception ex)
                {
                  
                    MessageBox.Show("Error al agregar la reserva: " + ex.Message);
                }

            }

        }

        private void Boton_eliminar_Click(object sender, EventArgs e)
        {
            string query = "Delete frorm Reserva where IdReserva = @IdReserva";

            using (SqlConnection conn = Conexiones.Conectar())
            {
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@IdReserva", dataGridView1.CurrentRow.Cells["IdReserva"].Value);

                try
                {
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Reserva eliminada correctamente");
                    Reserva();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al eliminar la reserva: " + ex.Message);
                }
            }
        }

        string ID;
        private void Boton_Actualizar_Click(object sender, EventArgs e)
        {
            string query = "UPDATE Reserva SET IdUsuario = @IdUsuario, ISBN = @ISBN, FechaReserva = @FechaReserva, FechaRetorno = @FechaRetorno WHERE IdReserva = @IdReserva";

            using (SqlConnection conn = Conexiones.Conectar())
            {
                try
                {
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {      
                     cmd.Parameters.Add("@IdReserva", SqlDbType.Int).Value = Convert.ToInt32(ID);
                        cmd.Parameters.Add("@IdUsuario", SqlDbType.Int).Value = comboBox2.SelectedValue ?? DBNull.Value;
                        cmd.Parameters.Add("@ISBN", SqlDbType.VarChar).Value = comboBox1.SelectedValue ?? DBNull.Value;
                        cmd.Parameters.Add("@FechaReserva", SqlDbType.DateTime).Value = dateTimePicker1.Value;
                        cmd.Parameters.Add("@FechaRetorno", SqlDbType.DateTime).Value = dateTimePicker2.Value;

                  
                        cmd.ExecuteNonQuery();

                        MessageBox.Show("Reserva actualizada correctamente");
                        Reserva();
                    }
                }
                catch (SqlException sqlEx)
                {
                 
                    MessageBox.Show("Error SQL al actualizar la reserva: " + sqlEx.Message);
                }
                catch (Exception ex)
                {
           
                    MessageBox.Show("Error al actualizar la reserva: " + ex.Message);
                }
            }

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return; 

            var filaSeleccionada = dataGridView1.Rows[e.RowIndex];

            ID = Convert.ToString(filaSeleccionada.Cells["IdReserva"].Value);
            comboBox2.SelectedValue = filaSeleccionada.Cells["IDUsuario"].Value ?? DBNull.Value;
            comboBox1.SelectedValue = filaSeleccionada.Cells["ISBN"].Value ?? DBNull.Value;
          
            if (DateTime.TryParse(Convert.ToString(filaSeleccionada.Cells["FechaReserva"].Value), out DateTime fechaReserva))
            {
                dateTimePicker1.Value = fechaReserva;
            }

            if (DateTime.TryParse(Convert.ToString(filaSeleccionada.Cells["FechaRetorno"].Value), out DateTime fechaRetorno))
            {
                dateTimePicker2.Value = fechaRetorno;
            }
        }

        private void Boton_salir_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
