﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace ProyectoBiblio
{
    public partial class FormCliente : Form
    {

        private Conexion conexionDB = new Conexion ();
        public FormCliente()
        {
            InitializeComponent();
            Subir();
        }

        private void Subir()
        {
            string query = "Select * from Usuario";

            using (SqlConnection conn = conexionDB.Conectar())
            {
                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;
            }
        }

        private void FormCliente_Load(object sender, EventArgs e)
        {

        }

        private void Boton_agregar_Click(object sender, EventArgs e)
        {
            string query = "Insert Into Usuario (Nombre, Apellido, Email, Telefono) VALUES (@Nombre, @Apellido, @Email, @Telefono)";

            using (SqlConnection conn = conexionDB.Conectar())
            {

                try
                {
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                
                        cmd.Parameters.Add("@Nombre", SqlDbType.VarChar).Value = textBox5.Text.Trim();
                        cmd.Parameters.Add("@Apellido", SqlDbType.VarChar).Value = textBox2.Text.Trim();
                        cmd.Parameters.Add("@Email", SqlDbType.VarChar).Value = textBox4.Text.Trim();
                        cmd.Parameters.Add("@Telefono", SqlDbType.VarChar).Value = textBox1.Text.Trim();

                  
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Usuario agregado correctamente");

                        Subir(); 
                    }
                }
                catch (SqlException sqlEx)
                {
                   
                    MessageBox.Show("Error SQL al agregar el usuario: " + sqlEx.Message);
                }
                catch (Exception ex)
                {
                    
                    MessageBox.Show("Error al agregar el usuario: " + ex.Message);
                }

            }
        }
        string ID;
        private void Boton_eliminar_Click(object sender, EventArgs e)
        {
            string query = "DELETE FROM Usuario WHERE IdUsuario = @IdUsuario";

            using (SqlConnection conn = conexionDB.Conectar())
            {
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    // Asignación de parámetros usando Add y especificando el tipo de dato
                    cmd.Parameters.Add("@IdUsuario", SqlDbType.Int).Value = Convert.ToInt32(ID);

                    try
                    {
                        // Ejecutar el comando de eliminación
                        int filasAfectadas = cmd.ExecuteNonQuery();

                        if (filasAfectadas > 0)
                        {
                            MessageBox.Show("Usuario eliminado correctamente");
                            Subir(); // Llamar al método para actualizar la vista
                        }
                        else
                        {
                            MessageBox.Show("No se encontró ningún usuario con ese ID.");
                        }
                    }
                    catch (SqlException sqlEx)
                    {
                        // Manejo específico de excepciones de SQL
                        MessageBox.Show("Error SQL al eliminar usuario: " + sqlEx.Message);
                    }
                    catch (Exception ex)
                    {
                        // Manejo genérico de excepciones
                        MessageBox.Show("Error al eliminar usuario: " + ex.Message);
                    }
                }
            }

        }



        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

                ID = row.Cells[0].Value.ToString();
                textBox5.Text = row.Cells[1].Value.ToString();
                textBox2.Text = row.Cells[2].Value.ToString();
                textBox4.Text = row.Cells[3].Value.ToString();
                textBox1.Text = row.Cells[4].Value.ToString();
            }
        }

        private void Boton_Actualizar_Click(object sender, EventArgs e)
        {
            string query = "UPDATE Usuario SET Nombre = @Nombre, Apellido = @Apellido, Email = @Email, Telefono = @Telefono WHERE IdUsuario = @IdUsuario";

            using (SqlConnection conn = conexionDB.Conectar())
            {
                try
                {
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        // Asignación de parámetros con tipos específicos
                        cmd.Parameters.Add("@IdUsuario", SqlDbType.Int).Value = Convert.ToInt32(ID);
                        cmd.Parameters.Add("@Nombre", SqlDbType.VarChar).Value = textBox5.Text.Trim();
                        cmd.Parameters.Add("@Apellido", SqlDbType.VarChar).Value = textBox2.Text.Trim();
                        cmd.Parameters.Add("@Email", SqlDbType.VarChar).Value = textBox4.Text.Trim();
                        cmd.Parameters.Add("@Telefono", SqlDbType.VarChar).Value = textBox1.Text.Trim();

                        // Ejecutar la consulta de actualización
                        int filasAfectadas = cmd.ExecuteNonQuery();

                        if (filasAfectadas > 0)
                        {
                            MessageBox.Show("Usuario actualizado correctamente");
                            Subir(); // Actualiza los datos después de la actualización
                        }
                        else
                        {
                            MessageBox.Show("No se encontró ningún usuario con ese ID.");
                        }
                    }
                }
                catch (SqlException sqlEx)
                {
                    // Manejo específico de excepciones SQL
                    MessageBox.Show("Error SQL al actualizar el usuario: " + sqlEx.Message);
                }
                catch (Exception ex)
                {
                    // Manejo de excepciones generales
                    MessageBox.Show("Error al actualizar el usuario: " + ex.Message);
                }
            }

        }

        private void Boton_salir_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
